<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="maze" tilewidth="16" tileheight="16" tilecount="8375" columns="63">
 <image source="imgSource/maze.png" width="1008" height="528"/>
</tileset>

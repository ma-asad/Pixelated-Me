<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="forestTileset" tilewidth="16" tileheight="16" tilecount="48" columns="8">
 <image source="imgSource/forestTileset.png" width="128" height="96"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="props" tilewidth="16" tileheight="16" tilecount="364" columns="26">
 <image source="imgSource/props.png" width="416" height="224"/>
</tileset>
